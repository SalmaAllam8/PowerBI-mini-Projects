"use strict";

import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";

import FormattingSettingsCard = formattingSettings.SimpleCard;
import FormattingSettingsSlice = formattingSettings.Slice;
import FormattingSettingsModel = formattingSettings.Model;

class HeaderCardSettings extends FormattingSettingsCard {
    title = new formattingSettings.TextInput({
        name: "title",
        displayName: "Title",
        value: "Player Name",
        placeholder: "Title"
    });

    subtitle = new formattingSettings.TextInput({
        name: "subtitle",
        displayName: "Subtitle",
        value: "Attacking Output — This Season vs Own Career",
        placeholder: "Subtitle"
    });

    showIcon = new formattingSettings.ToggleSwitch({
        name: "showIcon",
        displayName: "Show icon",
        value: false
    });

    iconText = new formattingSettings.TextInput({
        name: "iconText",
        displayName: "Icon (emoji)",
        value: "⚽",
        placeholder: "⚽"
    });

    titleColor = new formattingSettings.ColorPicker({
        name: "titleColor",
        displayName: "Title color",
        value: { value: "#1a1a1a" }
    });

    subtitleColor = new formattingSettings.ColorPicker({
        name: "subtitleColor",
        displayName: "Subtitle color",
        value: { value: "#6b6b76" }
    });

    titleFontSize = new formattingSettings.NumUpDown({
        name: "titleFontSize",
        displayName: "Title font size",
        value: 22
    });

    subtitleFontSize = new formattingSettings.NumUpDown({
        name: "subtitleFontSize",
        displayName: "Subtitle font size",
        value: 12
    });

    name: string = "header";
    displayName: string = "Header";
    slices: Array<FormattingSettingsSlice> = [
        this.title, this.subtitle, this.showIcon, this.iconText,
        this.titleColor, this.subtitleColor, this.titleFontSize, this.subtitleFontSize
    ];
}

class ChartCardSettings extends FormattingSettingsCard {
    backgroundColor = new formattingSettings.ColorPicker({
        name: "backgroundColor",
        displayName: "Background color",
        value: { value: "#ffffff" }
    });

    transparentBackground = new formattingSettings.ToggleSwitch({
        name: "transparentBackground",
        displayName: "Transparent background",
        value: true
    });

    fillColor = new formattingSettings.ColorPicker({
        name: "fillColor",
        displayName: "Value fill color",
        value: { value: "#f3625f" }
    });

    trackColor = new formattingSettings.ColorPicker({
        name: "trackColor",
        displayName: "Track color",
        value: { value: "#4a2026" }
    });

    centerHoleColor = new formattingSettings.ColorPicker({
        name: "centerHoleColor",
        displayName: "Center hole color",
        value: { value: "#ffffff" }
    });

    outerRingColor = new formattingSettings.ColorPicker({
        name: "outerRingColor",
        displayName: "Outer ring color",
        value: { value: "#3a3540" }
    });

    labelColor = new formattingSettings.ColorPicker({
        name: "labelColor",
        displayName: "Category label color",
        value: { value: "#1a1a1a" }
    });

    labelFontSize = new formattingSettings.NumUpDown({
        name: "labelFontSize",
        displayName: "Category label font size",
        value: 12
    });

    badgeFillColor = new formattingSettings.ColorPicker({
        name: "badgeFillColor",
        displayName: "Value badge fill",
        value: { value: "#ffffff" }
    });

    badgeBorderColor = new formattingSettings.ColorPicker({
        name: "badgeBorderColor",
        displayName: "Value badge border",
        value: { value: "#f3625f" }
    });

    badgeTextColor = new formattingSettings.ColorPicker({
        name: "badgeTextColor",
        displayName: "Value badge text",
        value: { value: "#1a1a1a" }
    });

    badgeFontSize = new formattingSettings.NumUpDown({
        name: "badgeFontSize",
        displayName: "Value badge font size",
        value: 13
    });

    innerRadiusPct = new formattingSettings.NumUpDown({
        name: "innerRadiusPct",
        displayName: "Center hole size (%)",
        value: 18
    });

    name: string = "chart";
    displayName: string = "Chart";
    slices: Array<FormattingSettingsSlice> = [
        this.backgroundColor, this.transparentBackground, this.fillColor, this.trackColor, this.centerHoleColor,
        this.outerRingColor, this.labelColor, this.labelFontSize,
        this.badgeFillColor, this.badgeBorderColor, this.badgeTextColor, this.badgeFontSize,
        this.innerRadiusPct
    ];
}

export class VisualFormattingSettingsModel extends FormattingSettingsModel {
    headerCard = new HeaderCardSettings();
    chartCard = new ChartCardSettings();

    cards = [this.headerCard, this.chartCard];
}
