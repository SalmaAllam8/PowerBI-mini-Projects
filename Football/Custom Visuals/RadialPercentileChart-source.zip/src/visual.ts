"use strict";

import powerbi from "powerbi-visuals-api";
import * as d3 from "d3";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import "./../style/visual.less";

import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisual = powerbi.extensibility.visual.IVisual;
import IVisualEventService = powerbi.extensibility.IVisualEventService;
import DataView = powerbi.DataView;

import { VisualFormattingSettingsModel } from "./settings";

interface MetricRow {
    metric: string;
    value: number;
}

function polarToXY(radius: number, angleRad: number): { x: number; y: number } {
    return { x: radius * Math.sin(angleRad), y: -radius * Math.cos(angleRad) };
}

export class Visual implements IVisual {
    private events: IVisualEventService;
    private target: HTMLElement;
    private formattingSettings: VisualFormattingSettingsModel;
    private formattingSettingsService: FormattingSettingsService;

    private root: d3.Selection<HTMLDivElement, unknown, null, undefined>;
    private headerDiv: d3.Selection<HTMLDivElement, unknown, null, undefined>;
    private headerIcon: d3.Selection<HTMLSpanElement, unknown, null, undefined>;
    private titleDiv: d3.Selection<HTMLDivElement, unknown, null, undefined>;
    private subtitleDiv: d3.Selection<HTMLDivElement, unknown, null, undefined>;
    private chartContainer: d3.Selection<HTMLDivElement, unknown, null, undefined>;
    private svg: d3.Selection<SVGSVGElement, unknown, null, undefined>;
    private chartGroup: d3.Selection<SVGGElement, unknown, null, undefined>;

    constructor(options: VisualConstructorOptions) {
        this.events = options.host.eventService;
        this.formattingSettingsService = new FormattingSettingsService();
        this.target = options.element;

        this.root = d3.select(this.target).append("div").attr("class", "rsc-root");

        this.headerDiv = this.root.append("div").attr("class", "rsc-header");
        this.headerIcon = this.headerDiv.append("span").attr("class", "rsc-header-icon");
        this.titleDiv = this.headerDiv.append("div").attr("class", "rsc-title");
        this.subtitleDiv = this.headerDiv.append("div").attr("class", "rsc-subtitle");

        this.chartContainer = this.root.append("div").attr("class", "rsc-chart-container");
        this.svg = this.chartContainer.append("svg").attr("class", "rsc-svg");
        this.chartGroup = this.svg.append("g").attr("class", "rsc-chart-group");
    }

    private extractData(dataView: DataView): MetricRow[] {
        const rows: MetricRow[] = [];
        if (!dataView || !dataView.table || !dataView.table.rows || !dataView.table.columns) {
            return rows;
        }

        const columns = dataView.table.columns;
        const tableRows = dataView.table.rows;

        const findIdx = (role: string) => columns.findIndex(c => c.roles && c.roles[role]);
        const metricIdx = findIdx("metric");
        const valueIdx = findIdx("value");

        for (const row of tableRows) {
            rows.push({
                metric: metricIdx >= 0 && row[metricIdx] != null ? String(row[metricIdx]) : "",
                value: valueIdx >= 0 ? Number(row[valueIdx]) : 0
            });
        }
        return rows;
    }

    public update(options: VisualUpdateOptions) {
        this.events.renderingStarted(options);
        try {
            const dataView = options.dataViews && options.dataViews[0];
            this.formattingSettings = this.formattingSettingsService.populateFormattingSettingsModel(VisualFormattingSettingsModel, dataView);

            const header = this.formattingSettings.headerCard;
            const chart = this.formattingSettings.chartCard;

            this.root.style("background-color", chart.transparentBackground.value ? "transparent" : chart.backgroundColor.value.value);

            this.headerIcon.text(header.iconText.value).style("display", header.showIcon.value ? "inline" : "none");
            this.titleDiv.text(header.title.value)
                .style("color", header.titleColor.value.value)
                .style("font-size", header.titleFontSize.value + "px");
            this.subtitleDiv.text(header.subtitle.value)
                .style("color", header.subtitleColor.value.value)
                .style("font-size", header.subtitleFontSize.value + "px")
                .style("display", header.subtitle.value ? "block" : "none");

            const rows = this.extractData(dataView);

            const totalWidth = options.viewport.width;
            const totalHeight = options.viewport.height;

            const headerEstimate = 14 + header.titleFontSize.value * 1.3 +
                (header.subtitle.value ? (header.subtitleFontSize.value * 1.3 + 4) : 0) + 10;
            const chartHeight = Math.max(40, totalHeight - headerEstimate);
            const chartWidth = Math.max(40, totalWidth);

            this.svg.attr("width", chartWidth).attr("height", chartHeight);

            const margin = 44;
            const radius = Math.max(10, Math.min(chartWidth, chartHeight) / 2 - margin);
            const innerRadius = radius * (chart.innerRadiusPct.value / 100);

            this.chartGroup.attr("transform", `translate(${chartWidth / 2},${chartHeight / 2})`);
            this.chartGroup.selectAll("*").remove();

            if (rows.length === 0) {
                this.events.renderingFinished(options);
                return;
            }

            // Outer ring
            this.chartGroup.append("circle")
                .attr("r", radius)
                .attr("fill", "none")
                .attr("stroke", chart.outerRingColor.value.value)
                .attr("stroke-width", 2);

            const n = rows.length;
            const angleStep = (2 * Math.PI) / n;
            const padAngle = Math.min(0.04, angleStep * 0.12);

            const arcGen = d3.arc<{ startAngle: number; endAngle: number; innerRadius: number; outerRadius: number }>()
                .padAngle(padAngle)
                .padRadius(innerRadius)
                .innerRadius(d => d.innerRadius)
                .outerRadius(d => d.outerRadius);

            rows.forEach((d, i) => {
                const startAngle = i * angleStep;
                const endAngle = startAngle + angleStep;
                const midAngle = (startAngle + endAngle) / 2;
                const clampedValue = Math.max(0, Math.min(100, d.value));
                const fillRadius = innerRadius + (clampedValue / 100) * (radius - innerRadius);

                // Track wedge
                this.chartGroup.append("path")
                    .attr("d", arcGen({ startAngle, endAngle, innerRadius, outerRadius: radius }))
                    .attr("fill", chart.trackColor.value.value);

                // Fill wedge
                if (fillRadius > innerRadius) {
                    this.chartGroup.append("path")
                        .attr("d", arcGen({ startAngle, endAngle, innerRadius, outerRadius: fillRadius }))
                        .attr("fill", chart.fillColor.value.value);
                }
            });

            // Center hole (drawn after wedges to keep a crisp circle)
            this.chartGroup.append("circle")
                .attr("r", innerRadius)
                .attr("fill", chart.centerHoleColor.value.value);

            // Category labels (horizontal)
            const labelRadius = radius + 16;
            rows.forEach((d, i) => {
                const startAngle = i * angleStep;
                const endAngle = startAngle + angleStep;
                const midAngle = (startAngle + endAngle) / 2;
                const pos = polarToXY(labelRadius, midAngle);

                // Pick anchor/baseline from which side of the circle the label falls on,
                // so text reads outward instead of overlapping the ring.
                const xThreshold = 6;
                let anchor: string;
                if (pos.x > xThreshold) anchor = "start";
                else if (pos.x < -xThreshold) anchor = "end";
                else anchor = "middle";

                let baseline: string;
                if (pos.y < -xThreshold) baseline = "auto";
                else if (pos.y > xThreshold) baseline = "hanging";
                else baseline = "middle";

                this.chartGroup.append("text")
                    .attr("class", "rsc-label")
                    .attr("x", pos.x)
                    .attr("y", pos.y)
                    .attr("text-anchor", anchor)
                    .attr("dominant-baseline", baseline)
                    .attr("fill", chart.labelColor.value.value)
                    .style("font-size", chart.labelFontSize.value + "px")
                    .style("font-weight", "700")
                    .text(d.metric);
            });

            // Value badges
            rows.forEach((d, i) => {
                const startAngle = i * angleStep;
                const endAngle = startAngle + angleStep;
                const midAngle = (startAngle + endAngle) / 2;
                const clampedValue = Math.max(0, Math.min(100, d.value));
                const fillRadius = innerRadius + (clampedValue / 100) * (radius - innerRadius);
                const badgeRadius = Math.max(innerRadius + 14, fillRadius);
                const pos = polarToXY(badgeRadius, midAngle);

                const badgeGroup = this.chartGroup.append("g")
                    .attr("class", "rsc-badge")
                    .attr("transform", `translate(${pos.x},${pos.y})`);

                const text = badgeGroup.append("text")
                    .attr("text-anchor", "middle")
                    .attr("dominant-baseline", "middle")
                    .attr("fill", chart.badgeTextColor.value.value)
                    .style("font-size", chart.badgeFontSize.value + "px")
                    .style("font-weight", "700")
                    .text(Math.round(d.value).toString());

                const textNode = text.node();
                const bbox = textNode ? textNode.getBBox() : { width: 20, height: 14, x: -10, y: -7 };
                const padX = 6;
                const padY = 3;

                badgeGroup.insert("rect", "text")
                    .attr("x", bbox.x - padX)
                    .attr("y", bbox.y - padY)
                    .attr("width", bbox.width + padX * 2)
                    .attr("height", bbox.height + padY * 2)
                    .attr("rx", 4)
                    .attr("fill", chart.badgeFillColor.value.value)
                    .attr("stroke", chart.badgeBorderColor.value.value)
                    .attr("stroke-width", 1.5);
            });

            this.events.renderingFinished(options);
        }
        catch (error) {
            console.log('Error in update method', error);
            this.events.renderingFailed(options, String(error));
        }
    }

    public getFormattingModel(): powerbi.visuals.FormattingModel {
        return this.formattingSettingsService.buildFormattingModel(this.formattingSettings);
    }
}
